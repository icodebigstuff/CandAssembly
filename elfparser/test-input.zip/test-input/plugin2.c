#include <stdio.h>
void triple(int *xp){
  *xp = *xp * 3;
  return;
}
